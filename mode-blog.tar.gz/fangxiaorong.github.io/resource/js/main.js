/* Author: Max Degterev @suprMax */
var Zepto = Zepto || undefined, marked = marked || undefined, Editor = Editor || undefined, Hasher = Hasher || undefined;

(function ($) {
    'use strict';
    var DEFAULTS, interpolate, easing, scrollNode;
    DEFAULTS = {
        endY: $.os.android ? 1 : 0,
        duration: 200,
        updateRate: 15
    };

    interpolate = function (source, target, shift) {
        return (source + (target - source) * shift);
    };

    easing = function (pos) {
        return (-Math.cos(pos * Math.PI) / 2) + 0.5;
    };

    scrollNode = function (settings) {
        var options, self, startY, startT, finishT, animate;
        
        options = $.extend({}, DEFAULTS, settings);
        self = this;
        function scrollTo(offsetY) {
            if (self === window) {
                self.scrollTo(0, offsetY);
            } else {
                self.scrollTop = offsetY;
            }
        }
        
        if (options.duration === 0) {
            scrollTo(options.endY);
            if (typeof options.callback === 'function') {
                options.callback();
            }
            return;
        }

        startY = (self === window) ? self.pageYOffset : this.scrollTop;
        startT = Date.now();
        finishT = startT + options.duration;

        animate = function () {
            var now = Date.now(), shift = (now > finishT) ? 1 : (now - startT) / options.duration;

            scrollTo(interpolate(startY, options.endY, easing(shift)));

            if (now < finishT) {
                setTimeout(animate, options.updateRate);
            } else {
                if (typeof options.callback === 'function') {
                    options.callback();
                }
            }
        };

        animate();
    };

    $.scrollTo = function () {
        var args = arguments;
        scrollNode.apply(window, args);
    };

    $.fn.scrollTo = function () {
        if (this.length) {
            var args = arguments;
            this.forEach(function (elem, index) {
                scrollNode.apply(elem, args);
            });
        }
    };
}(Zepto));

(function ($) {
    'use strict';
    var callbackEvent, realLoadScript, loadScript;
    
    callbackEvent = function (callback) {
        if (typeof callback === 'function') {
            callback();
        }
        if ($.loadScriptData.length > 0) {
            $.loadScriptData.shift();
            realLoadScript();
        }
    };
    realLoadScript = function () {
        if ($.loadScriptData.length <= 0) {
            return;
        }
        
        var scripts = $("script"),
            head = document.getElementsByTagName('head')[0],
            js = document.createElement('script'),
            loadData = $.loadScriptData[0];
        
        js.setAttribute('type', 'text/javascript');
        js.setAttribute('src', loadData.url);
        head.appendChild(js);
        
        if (document.all) { //IE
            js.onreadystatechange = function () {
                if (js.readyState === 'loaded' || js.readyState === 'complete') {
                    callbackEvent(loadData.callback);
                }
            };
        } else {
            js.onload = function () {
                callbackEvent(loadData.callback);
            };
        }
    };
    loadScript = function (url, callback) {
        $.loadScriptData.push({url: url, callback: callback});
        
        if ($.loadScriptData.length === 1) {
            realLoadScript();
        }
    };

    $.loadScriptData = [];
    $.loadScript = loadScript;
}(Zepto));

Function.prototype.Apply = function (thisObj) {
    'use strict';
    var self = this;
    return function (data) {
        return self.apply(thisObj, [data]);
    };
};

(function ($) {
    'use strict';
    var Plugin = function (element, options) {
        this.options = $.extend({}, Plugin.defaults, options);
        this.$element = $(element);
        this.init([]);
    };
    Plugin.pluginName = "messageBox";
    Plugin.dataName = "messageBoxData";
    Plugin.version = "1.0.0";
    Plugin.defaults = {};
    Plugin.prototype = {
        init: function (option) {
        },
        addMessage: function (option) {
        }
    };
    $.fn[Plugin.pluginName] = function (option, params) {
        var $this, data, options;
        $this = $(this);
        data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        options = typeof option === 'object' && option;
        if (!data) {
            $.fn[Plugin.pluginName].pluginData.index += 1;
            $.fn[Plugin.pluginName].pluginData[$.fn[Plugin.pluginName].pluginData.index] = new Plugin(this, options);
            $this.data(Plugin.dataName, $.fn[Plugin.pluginName].pluginData.index);
            data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        }
        if (typeof option === 'string') {
            data[option](params);
        }
    };
    $.fn[Plugin.pluginName].pluginData = {index: 0};
    $.fn[Plugin.pluginName].Constructor = Plugin;
}(Zepto));

(function ($) {
    'use strict';
    var Plugin, old;
    Plugin = function (element, options) {
        this.options = $.extend({}, Plugin.defaults, options);
        this.$element = $(element);
        this.$inputElement = undefined;
        this.markdownEditor = undefined;
        this.init();
    };
    Plugin.pluginName = "articleContent";
    Plugin.dataName = "articleData";
    Plugin.version = "1.0.0";
    Plugin.defaults = {};
    Plugin.prototype = {
        init: function () {
            this.$element.html("");
        },
        clear: function () {
            this.$element.html("");
        },
        addHtmlArticle: function (option) {
            var cc = [];
            cc.push('<div class="article">');
            cc.push('<div class="head">');
            cc.push('<div class="face"><img src="resource/images/favicon.ico" /></div>');
            if (option.detail) {
                cc.push('<div class="title nowrap"><a>' + option.title + '</a></div>');
            } else {
                /*jslint nomen:true */
                cc.push('<div class="title nowrap"><a href="#/article/' + option._id + '">' + option.title + '</a></div>');
            }
            cc.push('<div class="descript nowrap">' + option.create + ' by ' + option.author + ' (' + option.category + ')</div>');
            cc.push('</div>');
            cc.push('<div class="body">' + option.content + '</div>');
            if (!option.detail) {
                cc.push('<div class="more"><a href="#">Read More...</a></div>');
            }
            cc.push('</div>');
            cc = $(cc.join('')).appendTo(this.$element);
            
            if (option.scroll) {
                this.$element.scrollTo({
                    endY: cc.offset().top - $(this.$element.children()[0]).offset().top,
                    duration: 3000
                });
            }
        },
        addMarkdownArticle: function (option) {
            option.content = marked(option.content || "None");
            this.addHtmlArticle(option);
        },
        addLog: function (log) {
            this.$element.append("<div>" + log.toString() + "</div>");
        },
        addMessage: function (option) {
            var message, cc;
            message = option.message;
            cc = [];
            cc.push('<div class="message">');
            if (message.isSelf) {
                cc.push('<img class="logo" src="resource/images/favicon.ico" style="float:right;">');
                cc.push('<div class="bubble bubble_primary right" style="float:right;">');
            } else {
                cc.push('<img class="logo" src="resource/images/favicon.ico" style="float:left;">');
                cc.push('<div class="bubble bubble_primary left" style="float:left;">');
            }
            cc.push('<div style="padding: 8px 8px 8px 8px;">');
            cc.push(message.content);
            cc.push('</div>');
            cc.push('</div></div>');
            cc = $(cc.join('')).appendTo(this.$element);
            
            if (option.scroll) {
                this.$element.scrollTo({
                    endY: this.$element.scrollHeight() - this.$element.height(),
                    duration: 3000
                });
            }
        },
        addMarkdownEditor: function () {
            if (!this.markdownEditor) {
                this.$element.append('<textarea id="markdownArea"></textarea>');
                var textArea = $("#markdownArea").first()[0];
                this.markdownEditor = new Editor({element: textArea,
                                                  selfEnterCallback: this.addArticleEvent.Apply(this)});
                this.markdownEditor.render();
            }
        },
        addArticleEvent: function () {
            var contentArray, title, content, url, data;
            contentArray = this.markdownEditor.codemirror.getValue().replace(/(^\s*)|(\s*$)/g, "").split('\n');
            if (contentArray.length < 3) {
                window.alert("内容不全！");
            } else if ((contentArray[0].substr(0, 4) !== "### ") ||
                       (contentArray[1].indexOf("---") !== 0)) {
                window.alert("文章标题不对");
            } else {
                title = contentArray[0].substring(4).replace(/(^\s*)|(\s*$)/g, "");
                contentArray.splice(0, 2);
                content = contentArray.join("\n");
                window.alert(title);
                url = 'http://45.78.24.75:8000/article/add?callback=?';
                data = {title: title, category: "Life", name: "fscience", content: content};
                $.ajaxJSONP({
                    url: url,
                    data: data,
                    success: function (data) {
                        window.alert("发送成功！");
                    },
                    complete: function (xhr, status) {
                        $(".loading").hide();
                    }
                });
            }
        },
        addInputView: function () {
            var obj, range;
            if (!this.$inputElement) {
                this.$element.append('<textarea id="inputArea" class="inputArea"></textarea>');
                this.$inputElement = $("#inputArea").first();
                this.$inputElement.on('keyup', this.onSendMessageEvent.Apply(this));
            } else {
                this.$inputElement.remove();
                this.$element.append(this.$inputElement);
            }
            //设置焦点
            obj = this.$inputElement[0];
            if (obj.setSelectionRange) {
                setTimeout(function () {
                    obj.setSelectionRange(0, 0);
                    obj.focus();
                }, 100);
            } else {
                if (obj.createTextRange) {
                    range = obj.createTextRange();
                    range.collapse(true);
                    range.moveEnd("character", 0);
                    range.moveStart("character", 0);
                    range.select();
                }
                try { obj.focus(); } catch (e) {}
            }
        },
        onSendMessageEvent: function (event) {
            if (event.keyCode === 13) {
                var $inputTextArea = $(event.target);
                this.addMessage({message: { content: $inputTextArea.val(), isSelf: true}});
                $inputTextArea.val("");
                this.addInputView();
            }
        }
    };
    $.fn.scrollHeight = function () {
        var totalHeight = 0;
        if (this.length) {
            this.children().forEach(function (elem, index) {
                totalHeight += $(elem).height();
            });
        }
        return totalHeight;
    };
    old = $.fn[Plugin.pluginName];
    $.fn[Plugin.pluginName] = function (option, params) {
        var $this, data, options;
        $this = $(this);
        data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        options = typeof option === 'object' && option;
        //只实例化一次，后续如果再次调用了该插件时，则直接获取缓存的对象
        if (!data) {
            //zepto的data方法只能保存字符串，所以用此方法解决一下
            $.fn[Plugin.pluginName].pluginData.index += 1;
            $.fn[Plugin.pluginName].pluginData[$.fn[Plugin.pluginName].pluginData.index] = new Plugin(this, options);
            $this.data(Plugin.dataName, $.fn[Plugin.pluginName].pluginData.index);
            data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        }
        //如果插件的参数是一个字符串，则直接调用插件的名称为此字符串方法
        if (typeof option === 'string') {
            return data[option](params);
        }
    };
    //zepto的data方法只能保存字符串，所以用一个对象来存储data
    $.fn[Plugin.pluginName].pluginData = {index: 0};
    $.fn[Plugin.pluginName].Constructor = Plugin;
    //为插件增加 noConflict 方法，在插件重名时可以释放控制权
    $.fn[Plugin.pluginName].noConflict = function () {
        $.fn[Plugin.pluginName] = old;
        return this;
    };
    
    //扩展，自动
    $(document).ready(function () {
        $('[data-role="' + Plugin.pluginName + '"]').each(function () {
            var $this, data;
            $this = $(this);
            data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];

            $.fn[Plugin.pluginName].call($this, data);
        });
    });
}(Zepto));

(function ($) {
    'use strict';
    var SideItemGroup, Plugin;
    SideItemGroup = function (element, callback) {
        this.itemArray = [];
        this.$element = element;
        this.callback = callback;
    };
    SideItemGroup.prototype = {
        itemIndex: function (itemInfo) {
            var index, item;
            for (index = 0; index < this.itemArray.length; index += 1) {
                item = this.itemArray[index];
                if (item.isEqual(itemInfo)) {
                    return index;
                }
            }
            return -1;
        },
        pushItem: function (itemInfo) {
            var index, item;
            
            index = this.itemIndex(itemInfo);
            if (index >= 0) {
                item = this.itemArray[index];
                if (index !== (this.itemArray.length - 1)) {
                    this.itemArray.splice(index, 1);
                    this.triggleEvent(item, index);
                    item.$element.remove();
                }
            } else {
                item = itemInfo;
                item.$element = $(item.getItemElementTemp());
            }
            if (index !== (this.itemArray.length - 1)) {
                if (this.itemArray.length > 0) {
                    item.$element = item.$element.insertAfter(this.itemArray[this.itemArray.length - 1].$element[0]);
                } else {
                    item.$element = item.$element.appendTo(this.$element[0]);
                }
                this.itemArray.push(item);
                this.triggleEvent(item, this.itemArray.length - 1);
            }
            if (index === (this.itemArray.length - 1)) {
                item.onElementInited.apply(item, item.$element);
            }
            
            return item;
        },
        popItem: function () {
            if (this.itemArray.length > 0) {
                var item = this.itemArray.pop();
                this.triggleEvent(item, this.itemArray.length);
            }
        },
        unshiftItem: function (itemInfo) {
            var index, item;
            
            index = this.itemIndex(itemInfo);
            if (index >= 0) {
                item = this.itemArray[index];
                if (index !== 0) {
                    this.itemArray.splice(index, 1);
                    this.triggleEvent(item, index);
                    item.$element.remove();
                }
            } else {
                item = itemInfo;
                item.$element = $(item.getItemElementTemp());
            }
            if (index !== 0) {
                if (this.itemArray.length > 0) {
                    item.$element = item.$element.insertBefore(this.itemArray[0].$element[0]);
                } else {
                    item.$element = item.$element.appendTo(this.$element[0]);
                }
                this.itemArray.unshift(item);
                this.triggleEvent(item, 0);
            }
            if (index === -1) {
                item.onElementInited.apply(item, item.$element);
            }
            
            return item;
        },
        shiftItem: function (itemInfo) {
            if (this.itemArray.length > 0) {
                var item = this.itemArray.shift();
                this.triggleEvent(item, 0);
            }
        },
        clear: function () {
            this.itemArray.length = 0;
            this.triggleEvent(undefined, -1);
        },
        triggleEvent: function (itemInfo, index) {
            if (this.callback !== undefined) {
                this.callback(this.itemArray, itemInfo, index);
            }
        }
    };
    
    Plugin = function (element, options) {
        this.options = $.extend({}, Plugin.defaults, options);
        this.rootGroup = new SideItemGroup($(element));
        this.init();
    };
    Plugin.pluginName = "sideBar";
    Plugin.dataName = "sideBarData";
    Plugin.version = "1.0.0";
    Plugin.defaults = {};
    Plugin.prototype = {
        init: function (option) {
            this.rootGroup.$element.html("");
        },
        sideItemChangeEvent: function (group, itemInfo, index) {
            
        },
        addItem: function (option) {
            var group = option.group || this.rootGroup;
            
            if (option.isTop) {
                return group.pushItem(option.item);
            } else {
                return group.unshiftItem(option.item);
            }
        },
        addItems: function (option) {
            var group = option.group || this.rootGroup;
            
//            if (option.isTop) {
//                var index = this;
//                var items = option.items;
//                for (var index in items) {
//                    var item = items[index];
//                    this.rootGroup.pushItem(option)
//                }
//            }
        },
        getItem: function (option) {
            var group, index;
            group = option.group || this.rootGroup;
            index = group.itemIndex(option.itemInfo);
            if (index !== -1) {
                return group.itemArray[index];
            }
            return undefined;
        }
    };
    $.fn[Plugin.pluginName] = function (option, params) {
        var $this, data, options;
        $this = $(this);
        data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        options = typeof option === 'object' && option;
        if (!data) {
            $.fn[Plugin.pluginName].pluginData.index += 1;
            $.fn[Plugin.pluginName].pluginData[$.fn[Plugin.pluginName].pluginData.index] = new Plugin(this, options);
            $this.data(Plugin.dataName, $.fn[Plugin.pluginName].pluginData.index);
            data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        }
        if (typeof option === 'string') {
            return data[option](params);
        }
    };
    $.fn[Plugin.pluginName].pluginData = {index: 0};
    $.fn[Plugin.pluginName].Constructor = Plugin;
    
    $(document).ready(function () {
        $('[data-role="' + Plugin.pluginName + '"]').each(function () {
            var $this, data;
            $this = $(this);
            data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
            $.fn[Plugin.pluginName].call($this, data);
        });
    });
}(Zepto));

/* Main Source*/
(function ($) {
    'use strict';
    $(document).ready(function () {
        /* Fix content block size to fit the browser */
        function resetContainer() {
            var docHeight = $(document).height();
            $(".container").height(docHeight - 50);
            $(".content-main").height(docHeight - 50 - 30);
        }
        $(window).resize(function () {
            resetContainer();
        });
        resetContainer();
    });
    
    function baseRequest(url, success, complete) {
        $(".loading").show();
        $.ajaxJSONP({
            url: 'http://127.0.0.1:9000/' + url + 'callback=?',
            success: success,
            complete: function (xhr, status) {
                window.console.info("complete");
                $(".loading").hide();
                if (complete) {
                    complete(xhr, status);
                }
            }
        });
    }
    
    function loop(count) {
        if (count > 0) {
            $(".content-main").articleContent("addMessage", {message: { content: 'This is a hello world message!!', isSelf: (Math.random() < 0.5)}});
            $(".content-main").scrollTo({
                endY: $(".content-main").height() + 200,
                duration: 300,
                callback: function () {
                    $(".content-main").articleContent("addInputView");
                    //loop(count - 1);
                }
            });
        }
    }
    
    function articlesHandler(page) {
        baseRequest('articles?', function (data) {
            var article, index;
            $(".content-main").articleContent("clear");
            for (index = 0; index < data.articles.length; index += 1) {
                article = data.articles[index];
                $(".content-main").articleContent("addMarkdownArticle", article);
            }
            $(".content-main").scrollTo({
                endY: 0,
                duration: 3000
            });
        });
    }
    function articleHandler(articleId) {
        baseRequest('article?id=' + articleId + '&', function (data) {
            var article = data.article;
            if (article) {
                article.detail = true;
                article.scroll = true;
                $(".content-main").articleContent("addMarkdownArticle", article);
            }
        });
    }
    function messageHandler() {
        $(".loading").hide();
        loop(30);
    }
    function newHandler() {
        baseRequest('articles?', function (data) {
            var article, index;
            $(".content-main").articleContent("clear");
            for (index = 0; index < data.articles.length; index += 1) {
                article = data.articles[index];
                article.descript = '2015-07-03 by fscience';
                $(".content-main").articleContent("addMarkdownArticle", article);
            }
        }, function () {
            $(".content-main").articleContent("addMarkdownEditor");
        });
    }
    function testHandler() {
//        $.loadScript("resource/js/im.js");
        
        $.loadScript("resource/js/music.js");
        
        $(".content-main").articleContent("clear");
        $(".loading").hide();
    }
    function dailyHandler(path) {
        if (path === "") {
            articlesHandler("0");
        } else {
            window.alert(path);
        }
    }
    
    Hasher.add("/articles/:page", articlesHandler);
    Hasher.add("/article/:articleId", articleHandler);
    Hasher.add("/message/:user", messageHandler);
    Hasher.add("/new/:user", newHandler);
    Hasher.add("/test/:test", testHandler);
    Hasher.add("/*/:test", dailyHandler);
    Hasher.setup();
    
    window.Log = function (log) {
        $(".content-main").articleContent("addLog", log);
    };
}(Zepto));
