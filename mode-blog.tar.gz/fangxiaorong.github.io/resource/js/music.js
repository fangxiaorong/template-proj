var Zepto = Zepto || undefined;

(function ($) {
    'use strict';
    
    var Plugin;
    
    Plugin = function (targetId) {
        this.targetId = targetId;
        this.$element = undefined;
        this.init();
    };
    Plugin.pluginName = "ExtMusic";
    Plugin.dataName = "ExtMusicData";
    
    Plugin.prototype = {
        init: function () {
            this.playList = ["http://data.smohan.net/upload/other/media/2015/05/2015051703.mp3",
                            "http://data.smohan.net/upload/other/media/2015/05/2015051701.mp3",
                            "http://data.smohan.net/upload/other/media/2015/05/2015051702.mp3",
                            "http://data.smohan.net/upload/other/media/2015/05/2015051704.mp3",
                            "http://data.smohan.net/upload/other/cxcy/music.mp3",
                            "http://data.smohan.net/upload/other/media/2015/05/2015051705.mp3"];
            this.playIndex = parseInt(Math.random() * this.playList.length, 10) - 2;
        },
        isEqual: function (conversation) {
            return (this.targetId === conversation.targetId);
        },
        getItemElementTemp: function () {
            var cc = [];
            cc.push('<div class="music"><audio></audio>');
            cc.push('<div class="icon-pause play"></div>');
            cc.push('<div class="progress"><div class="bar"></div></div>');
            cc.push('</div>');
            return cc.join('');
        },
        onElementInited: function (element) {
            $(element).attr('id', this.targetId);
            this.controllers = {
                $audio: $(element).find("audio"),
                $play: $(element).find(".play"),
                $progress: $(element).find(".progress")
            };
            this.controllers.$play.on('click', this.toggleMusic.Apply(this));
            this.controllers.$progress.on('click', this.changeProgress.Apply(this));
            this.controllers.$audio.on("timeupdate", this.playTimeUpdate.Apply(this), false);
            this.controllers.$audio.on("ended", this.playMusic.Apply(this), false);
            this.controllers.$audio[0].load();
        },
        playMusic: function (option) {
            this.playIndex = Math.max(Math.min(this.playIndex + 1, this.playList.length - 1), 0);
            this.controllers.$audio.attr('src', this.playList[this.playIndex]);
            this.controllers.$audio[0].currentTime = 0;
            this.resumeMusic();
        },
        toggleMusic: function (option) {
            if (this.controllers.$play.hasClass("start")) {
                this.pauseMusic();
            } else {
                this.resumeMusic();
            }
        },
        pauseMusic: function () {
            this.controllers.$audio[0].pause();
            this.controllers.$play.removeClass("start");
            this.controllers.$play.removeClass("icon-pause");
            this.controllers.$play.addClass("icon-play");
        },
        resumeMusic: function () {
            this.controllers.$audio[0].play();
            this.controllers.$play.addClass("start");
            this.controllers.$play.removeClass("icon-play");
            this.controllers.$play.addClass("icon-pause");
        },
        playTimeUpdate: function () {
            var audio = this.controllers.$audio[0], progressValue;
            if (!isNaN(audio.duration)) {
                progressValue = (audio.currentTime / audio.duration) * 100;
                this.$element.find(".bar").css('width', progressValue + "%");
            }
        },
        changeProgress: function (event) {
            var offset = event.offsetX,
                length = this.controllers.$progress.width(),
                audio = this.controllers.$audio[0];
            audio.currentTime = Math.max(Math.min((offset / length), 1), 0) * audio.duration;
        }
    };
    
    $.fn[Plugin.pluginName] = function (option, params) {
        var $this, data, options;
        $this = $(this);
        data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        options = typeof option === 'object' && option;
        if (!data) {
            $.fn[Plugin.pluginName].pluginData.index += 1;
            $.fn[Plugin.pluginName].pluginData[$.fn[Plugin.pluginName].pluginData.index] = new Plugin(this, options);
            $this.data(Plugin.dataName, $.fn[Plugin.pluginName].pluginData.index);
            data = $.fn[Plugin.pluginName].pluginData[$this.data(Plugin.dataName)];
        }
        if (typeof option === 'string') {
            return data[option](params);
        }
    };
    $.fn[Plugin.pluginName].pluginData = {index: 0};
    $.fn[Plugin.pluginName].Constructor = Plugin;
    
    function resolveZeptoObject($plugin) {
        $.fn[Plugin.pluginName].pluginData.index += 1;
        $.fn[Plugin.pluginName].pluginData[$.fn[Plugin.pluginName].pluginData.index] = $plugin;
        $plugin.$element.data(Plugin.dataName, $.fn[Plugin.pluginName].pluginData.index);
    }
    $(document).ready(function () {
        var $extMusic = $(".sider").sideBar("addItem", {item: new Plugin("music")});
        resolveZeptoObject($extMusic);
        
        $("#music").ExtMusic("playMusic");
    });
}(Zepto));