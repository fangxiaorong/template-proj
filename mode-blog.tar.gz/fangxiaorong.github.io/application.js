(function ($) {
    var UserModel = Backbone.Model.extend({
    });
    var HeadModel = Backbone.Model.extend({
    });
    var BodyModel = Backbone.Model.extend({
    });
    var SideModel = Backbone.Model.extend({
    });
    var ContentModel = Backbone.Model.extend({
    });
// })(jQuery);

// (function ($) {
    var HeadView = Backbone.View.extend({
        el: $("#headView"),
        initialize: function() {
            var user = new UserModel;
            user.fetch();
        },
        template: _.template($("#head_template").html()),
        render: function(context) {
            //加载模板到对应的el属性中
            $(this.el).html(this.template(context));
        }
    });
    
    var BodyView = Backbone.View.extend({
        el: $("#bodytView"),
    });
    
    var SideView = Backbone.View.extend({
        el: $("#sideView"),
    });
    
    var ContentView = Backbone.View.extend({
        el: $("#contentView"),
    });
// })(jQuery);

// (function ($) {
    var app_router = null;
    var Application = Backbone.Router.extend({
        views: {},
        routes: {
            // "posts/:id" : "getPost",
            // "manual": "manual",
            "*actions" : "defaultRoute"
        },
        loadView: function( route, action ){
            alert(route + "_" + action); // dashboard_graph
        },
        manual: function() {
            alert("call manual");
            app_router.navigate("/posts/" + 404, {trigger: true, replace: true});
        },
        defaultRoute : function(actions){
            alert(actions);
            if (this.views.headView === undefined) {
                this.views.headView = new HeadView;
            }
        }
    });
    new HeadView();
    app_router = new Application;
    Backbone.history.start();
})(jQuery);